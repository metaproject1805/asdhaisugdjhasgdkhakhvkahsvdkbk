from django.contrib import admin
from .models import Packages


admin.site.register(Packages)

# Register your models here.
