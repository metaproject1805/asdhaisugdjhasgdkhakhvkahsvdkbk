from django.contrib import admin
from .models import Investment

admin.site.register(Investment)

# Register your models here.
